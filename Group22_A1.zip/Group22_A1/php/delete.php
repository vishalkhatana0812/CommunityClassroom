<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <title>BDMH</title>
  </head>
  <body>
      <nav class="nav nav-pills nav-justified navbar navbar-dark bg-dark">
          <a class="nav-item nav-link" href="/">Home</a>
          <a class="nav-item nav-link " href="showTable.php">Clients</a>
          <a class="nav-item nav-link active" href="/otherQuery.php">Other Queries</a>
          
          
    </nav>
<div class="container p-3 my-3 border">
    <h1>Clients Details</h1>
        >
      <a href="/delhi.php" class="btn btn-success btn-lg btn-block" role="button">Client from Delhi</a>
      <a href="/patna.php" class="btn btn-danger btn-lg btn-block" role="button">Clients from Patna</a>
      <a href="/byName.php" class="btn btn-warning btn-lg btn-block" role="button">Whose Last Name is Sharma or Kumar</a>
      <a href="/delete.php" class="btn btn-danger btn-lg btn-block" role="button">Delete</a>
       <div class="container">
              <h2>Deleting the entry of Clients with age > 30</h2>           
              <table class="table table-dark table-striped table-hover">
                <thead>
                  <tr>
                    <th>Average Salary</th>
                  </tr>
                </thead>
                <tbody>   
                    
                      <?php
                    $host = 'db';  //the name of the mysql service inside the docker file.
                    $user = 'devuser';
                    $password = 'devpass';
                    $db = 'mydb';
                    $conn = new mysqli($host,$user,$password,$db);
                     if (!$conn) {
                      die ('connection failed'. mysqli_connect_error());
                    }
                      else{
                        echo 'successfully connected to MYSQL <br><br>';
                      }


                    $sql = "DELETE FROM Clients WHERE Age>30;";
                    if ($conn->query($sql) === TRUE) {
                      echo "Deleted  <br>";
                    } else {
                      echo "Error: " . $sql . "<br>" . $conn->error;
                    }
                    $sql="Select * from Clients";

                    $result = $conn->query($sql);
//                    if($result == True) echo "asdf";
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["ID"]. "</td><td>" . $row["FirstName"]. "</td><td>" . $row["LastName"]. "</td><td>" . $row["City"]. "</td><td>" .$row["Occupation"]. "</td><td>" . (string)$row["Age"]. "</td><td>". strval($row["Salary"]). "</td>";
                        echo "</tr>";
                    }



                    $conn -> close();
                    ?> 
                </tbody>
              </table>
            </div>
      <p id="demo"></p>
            
      </div> 
      <script>
            function avgSalary() {
              document.getElementById("demo").innerHTML = "Hello World";
            }
          
          function avgAge() {
              document.getElementById("demo").innerHTML = "Hello World";
              
            
            
            }
          function delhi() {
              document.getElementById("demo").innerHTML = "Hello World";
            
            }
          function countPatna() {
              document.getElementById("demo").innerHTML = "Hello World";
            
            }
          function byName() {
              document.getElementById("demo").innerHTML = "Hello World";
            
            }
      </script>
      
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>