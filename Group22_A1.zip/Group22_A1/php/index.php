<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <title>BDMH</title>
  </head>
  <body>
      <nav class="nav nav-pills nav-justified navbar navbar-dark bg-dark">
          <a class="nav-item nav-link active" href="/">Home</a>
          <a class="nav-item nav-link" href="showTable.php">Clients</a>
          <a class="nav-item nav-link" href="/otherQuery.php">Other Queries</a>

    </nav>
  <div class="container p-3 my-3 bg-primary text-black">
      <h1>BDMH</h1>
      
<div class="jumbotron jumbotron-fluid">

    <h1 class="display-4">Connecting to MYSQL Database</h1>
    <p class="lead">After connection we are creating a table and inserting few values in it.</p>
  
            <?php
            $host = 'db';  //the name of the mysql service inside the docker file.
            $user = 'devuser';
            $password = 'devpass';
            $db = 'mydb';
            $conn = new mysqli($host,$user,$password,$db);
             if (!$conn) {
              die ('connection failed'. mysqli_connect_error());
            }
              else{
                echo 'successfully connected to MYSQL <br>';
              }
//            $sql = "CREATE DATABASE mydb";
//            if ($conn->query($sql) === TRUE) {
//              echo "Database created successfully";
//            } else {
//              echo "Error creating database: " . $conn->error;
//            }      
      
            
            $sql="DROP TABLE IF EXISTS Clients;";
            $conn->query($sql);
               
            $sql="CREATE TABLE Clients (
                ID int , FirstName varchar(255), LastName varchar(255), City varchar(255), Occupation varchar(255), Age int, Salary int, PRIMARY KEY (ID)
            );";
            if ($conn->query($sql) === TRUE) {
              echo "New table created successfully <br>";
            } else {
              echo "Error: " . $sql . "<br>" . $conn->error;
            }
      
            $sql="Insert into Clients values (1, 'Rohit','Sharma', 'Mumbai', 'Accountant', 25, 10000)";
            if ($conn->query($sql) === TRUE) {
              echo "New Row Added to the Table <br>";
            } else {
              echo "Error: " . $sql . "<br>" . $conn->error;
            }
            $sql="Insert into Clients values (2, 'Rishabh','Pant', 'Delhi', 'Astrologer', 50, 40000)";
            if ($conn->query($sql) === TRUE) {
              echo "New Row Added to the Table  <br>";
            } else {
              echo "Error: " . $sql . "<br>" . $conn->error;
            }$sql="Insert into Clients values (3, 'Navdeep','Kumar', 'New Delhi', 'Engineer', 30, 20000)";
            if ($conn->query($sql) === TRUE) {
              echo "New Row Added to the Table  <br>";
            } else {
              echo "Error: " . $sql . "<br>" . $conn->error;
            }$sql="Insert into Clients values (4, 'srikant','patel', 'jabalpur', 'doctor', 40, 25000)";
            if ($conn->query($sql) === TRUE) {
              echo "New Row Added to the Table  <br>";
            } else {
              echo "Error: " . $sql . "<br>" . $conn->error;
            }$sql="Insert into Clients values (5, 'Prince','Yadav', 'Patna', 'Software Developer', 22, 20500)";
            if ($conn->query($sql) === TRUE) {
              echo "New Row Added to the Table  <br>";
            } else {
              echo "Error: " . $sql . "<br>" . $conn->error;
            }
      
            


            $conn -> close();
        ?>
   </div>
</div>   
      
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>